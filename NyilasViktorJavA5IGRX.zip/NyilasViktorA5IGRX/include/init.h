#ifndef INIT_H
#define INIT_H

/**
 * Initialize the OpenGL context.
 */
void init_opengl();

#endif /* INIT_H */
